$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/features/RealizarPesquisa.feature");
formatter.feature({
  "name": "Pesquisar no campo de busca da WebMotors",
  "description": "",
  "keyword": "Funcionalidade"
});
formatter.scenarioOutline({
  "name": "realizar acesso ao site da WebMotors a fim de pesquisar um automóvel especifico",
  "description": "",
  "keyword": "Esquema do Cenário",
  "tags": [
    {
      "name": "@PequisarWebMotors"
    }
  ]
});
formatter.step({
  "name": "que desejo acessar o site da WebMotors",
  "keyword": "Dado "
});
formatter.step({
  "name": "acionar a \"\u003cmarca\u003e\" do carro",
  "keyword": "Quando "
});
formatter.step({
  "name": "escolher o \"\u003cmodelo\u003e\"",
  "keyword": "E "
});
formatter.step({
  "name": "escolher a \"\u003cversão\u003e\"",
  "keyword": "E "
});
formatter.step({
  "name": "deve retornar a quantidade de veiculos",
  "keyword": "Então "
});
formatter.step({
  "name": "as opções de  \"\u003cmarca\u003e\" , \"\u003cmodelo\u003e\" e \"\u003cversão\u003e\" que foram informados na busca",
  "keyword": "E "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Exemplos",
  "rows": [
    {
      "cells": [
        "marca",
        "modelo",
        "versão"
      ]
    },
    {
      "cells": [
        "Honda",
        "CITY",
        "1.5 LX 16V FLEX 4P AUTOMÁTICO"
      ]
    }
  ]
});
formatter.scenario({
  "name": "realizar acesso ao site da WebMotors a fim de pesquisar um automóvel especifico",
  "description": "",
  "keyword": "Esquema do Cenário",
  "tags": [
    {
      "name": "@PequisarWebMotors"
    }
  ]
});
formatter.step({
  "name": "que desejo acessar o site da WebMotors",
  "keyword": "Dado "
});
formatter.match({
  "location": "StepDefinitionRealizarPesquisa.queDesejoAcessarSiteNaPaginaDeBusca()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "acionar a \"Honda\" do carro",
  "keyword": "Quando "
});
formatter.match({
  "location": "StepDefinitionRealizarPesquisa.acionarMarcaDoCarro(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "escolher o \"CITY\"",
  "keyword": "E "
});
formatter.match({
  "location": "StepDefinitionRealizarPesquisa.escolherModelo(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "escolher a \"1.5 LX 16V FLEX 4P AUTOMÁTICO\"",
  "keyword": "E "
});
formatter.match({
  "location": "StepDefinitionRealizarPesquisa.aVersaoDoVeiculo(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "deve retornar a quantidade de veiculos",
  "keyword": "Então "
});
formatter.match({
  "location": "StepDefinitionRealizarPesquisa.deveRetornarQuantidadeDeVeiculos()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "as opções de  \"Honda\" , \"CITY\" e \"1.5 LX 16V FLEX 4P AUTOMÁTICO\" que foram informados na busca",
  "keyword": "E "
});
formatter.match({
  "location": "StepDefinitionRealizarPesquisa.asOpcoesDeMarcaMmodeloVversaoQueForamInformadosNaBusca(String,String,String)"
});
formatter.result({
  "status": "passed"
});
});