# Desafio WebMotors

## ENTREGÁVEIS
Sabendo que para a próxima entrega no site de produção teremos que validar os campos de 
busca de "Marca", "Modelo" e "Versão" da página de resultado de busca da Webmotors, além 
da listagem de estoque de uma determinada loja

Os testes automatizados devem seguir os cenários de testes elaborados no item 1
1. Documento com os cenários de testes elaborado no formato de BDD
2. Teste automatizado de interface (Selenium Webdrive)
3. Teste automatizado de API (Postaman / SoupUI / Webdrive)
ITENS OBRIGATÓRIOS
Selecionar a marca e modelo abaixo obrigatoriamente no teste automatizado.
• Marca: Honda
• Modelo: City

## Tecnologias utilizadas
---
- Selenium
- Java
- Cucumber (BDD)
- Junit
---
## Executar o teste
Para executar o projeto, via Maven, basta seguir no seu terminal predileto para o diretório do projeto e executar o seguinte comando:
Para executar os scripts via terminal :
mvn test -Dcucumber.options="--tags @PequisarWebMotors"n test
```
Caso deseje executar pela IDE de sua preferência, executar o arquivo *RunPesquisaWebMotors.java* inicia todos os testes. 
---
## Evidencias
Ao executar os testes, evidencias estão em HTML estão sendo gravados dentro do diretório */cucumber-reports/html/*. 
Nesse report HTML, está registrada a execução dos casos de testes, juntamente com as descrições de sucesso/falha 
no testes executados.
---
